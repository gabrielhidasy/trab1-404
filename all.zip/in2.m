ADD M(3)
jump m(labelx)
ADD M(10)
.align 1
.word 64202
labelx:
.word -1

