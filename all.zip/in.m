@ teste02.s - testa diretivas basicas do montador

ADD M(1)
.align 1
.word 64202
.word 0b1010101111011110111011011
.word -1
.word -10
.word 0x9
.word 0x10000
.word 0x100000
.word 0x99090
.word 0o377777
.align 20
.word 0xFFFFFFFFFF


